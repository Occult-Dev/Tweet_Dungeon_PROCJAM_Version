self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "249113ebaabd4659a2b9",
    "url": "/css/app.622fcac7.css"
  },
  {
    "revision": "d319bfc08f14982fc2868420be4a6409",
    "url": "/img/dungeon-bg.d319bfc0.png"
  },
  {
    "revision": "dc6ecb3f6c1359eb3554835da40945f5",
    "url": "/img/logo.dc6ecb3f.png"
  },
  {
    "revision": "fe992e621b71eac6ef469dafe794d5f5",
    "url": "/index.html"
  },
  {
    "revision": "249113ebaabd4659a2b9",
    "url": "/js/app.e89a5dc0.js"
  },
  {
    "revision": "f12d0d30744e89155743",
    "url": "/js/chunk-vendors.06322681.js"
  },
  {
    "revision": "fd16cf70519dc56082d1c4ff231df24b",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);